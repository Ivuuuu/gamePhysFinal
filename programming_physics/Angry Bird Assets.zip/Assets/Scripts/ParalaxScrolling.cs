﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParalaxScrolling : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        camera = Camera.main;
        previousCameraTransform = camera.transform.position;
    }

    Camera camera;

    // Update is called once per frame
    void Update()
    {
        Vector3 delta = camera.transform.position - previousCameraTransform;
        delta.y = 0; delta.z = 0;
        transform.position += delta / ParallaxFactor;

        previousCameraTransform = camera.transform.position;
    }
        public float ParallaxFactor;
    Vector3 previousCameraTransform;
    }
